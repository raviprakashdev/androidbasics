package juicyapps.mak.dev.com.sqlitedb;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;


public class FingerDatabaseHelper extends SQLiteOpenHelper {

    // Database Version
    private static final int DATABASE_VERSION_FP_DB = 1;

    // Database Name
    private static final String DATABASE_NAME_FP_DB = "fingerprints_db";

    public FingerDatabaseHelper(Context context) {
        super(context, DATABASE_NAME_FP_DB, null, DATABASE_VERSION_FP_DB);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(FingerDatabaseModel.CREATE_TABLE_FINGER_DB);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db,  int oldVersion, int newVersion) {
        //drop table if exists
        db.execSQL("DROP TABLE IF EXISTS " + FingerDatabaseModel.FINGER_DB_TABLE_NAME);
        // Create tables again
        onCreate(db);
    }

    public List<FingerDatabaseModel> getAllModels() {
        List<FingerDatabaseModel> models = new ArrayList<>();
        // Select All Query
        String selectQuery = "SELECT  * FROM " + FingerDatabaseModel.FINGER_DB_TABLE_NAME + " ORDER BY " +
                FingerDatabaseModel.COLUMN_FINGERID_FINGER_DB + " DESC";

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                FingerDatabaseModel model = new FingerDatabaseModel();
                model.setRollno(cursor.getInt(cursor.getColumnIndex(FingerDatabaseModel.COLUMN_ROllNO_FINGER_DB)));
                model.setFingerid(cursor.getInt(cursor.getColumnIndex(FingerDatabaseModel.COLUMN_FINGERID_FINGER_DB)));
                model.setFingerimage(cursor.getString(cursor.getColumnIndex(FingerDatabaseModel.COLUMN_FINGERIMAGE_FINGER_DB)));
                model.setFingerstring(cursor.getString(cursor.getColumnIndex(FingerDatabaseModel.COLUMN_FINGERSTRING_FINGER_DB)));
                model.setCandidateImage(cursor.getString(cursor.getColumnIndex(FingerDatabaseModel.COLUMN_CANDIDATEIMAGE_FINGER_DB)));
                model.setStartDateTime(cursor.getString(cursor.getColumnIndex(FingerDatabaseModel.COLUMN_START_DATE_TIME_FINGER_DB)));
                model.setEndDateTime(cursor.getString(cursor.getColumnIndex(FingerDatabaseModel.COLUMN_END_DATE_TIME_FINGER_DB)));
                model.setStartFlag(cursor.getInt(cursor.getColumnIndex(FingerDatabaseModel.COLUMN_START_FLAG_FINGER_DB)));
                model.setEndFlag(cursor.getInt(cursor.getColumnIndex(FingerDatabaseModel.COLUMN_END_FLAG_FINGER_DB)));
                model.setDuration(cursor.getInt(cursor.getColumnIndex(FingerDatabaseModel.COLUMN_DURATION_FINGER_DB)));
                models.add(model);
            } while (cursor.moveToNext());
        }
        // close db connection
        db.close();

        // return notes list
        return models;
    }

    public long insertData(
            int rollno,
            String fingerimage,
            String fingerstring,
            String candidateImage,
            String startDateTime,
            String endDateTime,
            int startFlag,
            int endFlag,
            int duration
    ) {
        // get writable database as we want to write data
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        //finger id not added
        //finger id is on autoincrement
        values.put(FingerDatabaseModel.COLUMN_ROllNO_FINGER_DB, rollno );
        values.put(FingerDatabaseModel.COLUMN_FINGERSTRING_FINGER_DB, fingerstring );
        values.put(FingerDatabaseModel.COLUMN_FINGERIMAGE_FINGER_DB, fingerimage );
        values.put(FingerDatabaseModel.COLUMN_CANDIDATEIMAGE_FINGER_DB, candidateImage );
        values.put(FingerDatabaseModel.COLUMN_START_DATE_TIME_FINGER_DB,startDateTime);
        values.put(FingerDatabaseModel.COLUMN_END_DATE_TIME_FINGER_DB,endDateTime);
        values.put(FingerDatabaseModel.COLUMN_START_FLAG_FINGER_DB,startFlag);
        values.put(FingerDatabaseModel.COLUMN_END_FLAG_FINGER_DB,endFlag);
        values.put(FingerDatabaseModel.COLUMN_DURATION_FINGER_DB,duration);

        // insert row
        long id = db.insert(FingerDatabaseModel.FINGER_DB_TABLE_NAME, null, values);

        // close db connection
        db.close();

        // return newly inserted row id
        return id;
    }
    public FingerDatabaseModel getDatabaseModel(long id) {
        // get readable database as we are not inserting anything
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(FingerDatabaseModel.FINGER_DB_TABLE_NAME,
                new String[]{
                        FingerDatabaseModel.COLUMN_ROllNO_FINGER_DB,
                        FingerDatabaseModel.COLUMN_FINGERID_FINGER_DB,
                        FingerDatabaseModel.COLUMN_FINGERSTRING_FINGER_DB,
                        FingerDatabaseModel.COLUMN_FINGERIMAGE_FINGER_DB,
                        FingerDatabaseModel.COLUMN_CANDIDATEIMAGE_FINGER_DB,
                        FingerDatabaseModel.COLUMN_START_DATE_TIME_FINGER_DB,
                        FingerDatabaseModel.COLUMN_END_DATE_TIME_FINGER_DB,
                        FingerDatabaseModel.COLUMN_START_FLAG_FINGER_DB,
                        FingerDatabaseModel.COLUMN_END_FLAG_FINGER_DB,
                        FingerDatabaseModel.COLUMN_DURATION_FINGER_DB
                },
                FingerDatabaseModel.COLUMN_FINGERID_FINGER_DB + "=?",
                new String[]{String.valueOf(id)}, null, null, null, null);

        if (cursor != null)
            cursor.moveToFirst();

        // prepare model object
        FingerDatabaseModel model = new FingerDatabaseModel(
                cursor.getInt(cursor.getColumnIndex(FingerDatabaseModel.COLUMN_ROllNO_FINGER_DB)),
                cursor.getInt(cursor.getColumnIndex(FingerDatabaseModel.COLUMN_FINGERID_FINGER_DB)),
                cursor.getString(cursor.getColumnIndex(FingerDatabaseModel.COLUMN_FINGERIMAGE_FINGER_DB)),
                cursor.getString(cursor.getColumnIndex(FingerDatabaseModel.COLUMN_FINGERSTRING_FINGER_DB)),
                cursor.getString(cursor.getColumnIndex(FingerDatabaseModel.COLUMN_CANDIDATEIMAGE_FINGER_DB)),
                cursor.getString(cursor.getColumnIndex(FingerDatabaseModel.COLUMN_START_DATE_TIME_FINGER_DB)),
                cursor.getString(cursor.getColumnIndex(FingerDatabaseModel.COLUMN_END_DATE_TIME_FINGER_DB)),
                cursor.getInt(cursor.getColumnIndex(FingerDatabaseModel.COLUMN_START_FLAG_FINGER_DB)),
                cursor.getInt(cursor.getColumnIndex(FingerDatabaseModel.COLUMN_END_FLAG_FINGER_DB)),
                cursor.getInt(cursor.getColumnIndex(FingerDatabaseModel.COLUMN_DURATION_FINGER_DB))
        );

        // close the db connection
        cursor.close();

        return model;
    }
    public int getDatabaseModelCount() {
        // select all query
        String countQuery = "SELECT  * FROM " + FingerDatabaseModel.FINGER_DB_TABLE_NAME;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);

        int count = cursor.getCount();
        cursor.close();

        // return count
        return count;
    }

    public int updateData(FingerDatabaseModel dm) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(FingerDatabaseModel.COLUMN_ROllNO_FINGER_DB, dm.getRollno());
        values.put(FingerDatabaseModel.COLUMN_FINGERIMAGE_FINGER_DB,dm.getFingerimage());
        values.put(FingerDatabaseModel.COLUMN_FINGERSTRING_FINGER_DB,dm.getFingerstring());
        values.put(FingerDatabaseModel.COLUMN_CANDIDATEIMAGE_FINGER_DB,dm.getCandidateImage());
        values.put(FingerDatabaseModel.COLUMN_START_DATE_TIME_FINGER_DB,dm.getStartDateTime());
        values.put(FingerDatabaseModel.COLUMN_END_DATE_TIME_FINGER_DB,dm.getEndDateTime());
        values.put(FingerDatabaseModel.COLUMN_START_FLAG_FINGER_DB,dm.getStartFlag());
        values.put(FingerDatabaseModel.COLUMN_END_FLAG_FINGER_DB,dm.getEndFlag());
        values.put(FingerDatabaseModel.COLUMN_DURATION_FINGER_DB,dm.getDuration());
        // updating row
        return db.update(FingerDatabaseModel.FINGER_DB_TABLE_NAME, values, FingerDatabaseModel.COLUMN_FINGERID_FINGER_DB + " = ?",
                new String[]{String.valueOf(dm.getFingerid())});
    }

    public void deleteData(FingerDatabaseModel dm) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(FingerDatabaseModel.FINGER_DB_TABLE_NAME, FingerDatabaseModel.COLUMN_FINGERID_FINGER_DB + " = ?",
                new String[]{String.valueOf(dm.getFingerid())});
        db.close();
    }
}
