package juicyapps.mak.dev.com.sqlitedb;

public class FingerDatabaseModel {
    public static final String FINGER_DB_TABLE_NAME = "candidate_finger_db";

    public static final String COLUMN_FINGERID_FINGER_DB = "fingerid";
    public static final String COLUMN_ROllNO_FINGER_DB = "rollno";
    public static final String COLUMN_FINGERIMAGE_FINGER_DB = "fingerimage";
    public static final String COLUMN_FINGERSTRING_FINGER_DB = "fingerstring";
    public static final String COLUMN_CANDIDATEIMAGE_FINGER_DB = "candidateImage";
    public static final String COLUMN_START_DATE_TIME_FINGER_DB = "start_datetime";
    public static final String COLUMN_END_DATE_TIME_FINGER_DB = "end_datetime";
    public static final String COLUMN_START_FLAG_FINGER_DB = "start_flag";
    public static final String COLUMN_END_FLAG_FINGER_DB = "end_flag";
    public static final String COLUMN_DURATION_FINGER_DB = "duration";

    private int fingerid;
    private int rollno;
    private String fingerimage;
    private String fingerstring;
    private String candidateImage;
    private String startDateTime;
    private String endDateTime;
    private int startFlag;
    private int endFlag;
    private int duration;

    public FingerDatabaseModel() {
    }

    public FingerDatabaseModel(int fingerid, int rollno, String fingerimage){
        this.fingerid=fingerid;
        this.rollno=rollno;
        this.fingerimage=fingerimage;

    }
    public FingerDatabaseModel(
            int fingerid,
            int rollno,
            String fingerimage,
            String fingerstring,
            String candidateImage,
            String startDateTime,
            String endDateTime,
            int startFlag,
            int endFlag,
            int duration
    ){
        this.fingerid=fingerid;
        this.rollno=rollno;
        this.fingerimage=fingerimage;
        this.fingerstring=fingerstring;
        this.candidateImage=candidateImage;
        this.startDateTime = startDateTime;
        this.endDateTime = endDateTime;
        this.startFlag = startFlag;
        this.endFlag = endFlag;
        this.duration = duration;
    }

    public static final String CREATE_TABLE_FINGER_DB =
            "CREATE TABLE " + FINGER_DB_TABLE_NAME +  "("
                    + COLUMN_FINGERID_FINGER_DB
                    + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + COLUMN_ROllNO_FINGER_DB +" INTEGER,"
                    + COLUMN_FINGERIMAGE_FINGER_DB +" TEXT,"
                    + COLUMN_FINGERSTRING_FINGER_DB +" TEXT,"
                    + COLUMN_CANDIDATEIMAGE_FINGER_DB +" TEXT,"
                    + COLUMN_START_DATE_TIME_FINGER_DB +" TEXT,"
                    + COLUMN_END_DATE_TIME_FINGER_DB +" TEXT,"
                    + COLUMN_START_FLAG_FINGER_DB +" INTEGER,"
                    + COLUMN_END_FLAG_FINGER_DB +" INTEGER,"
                    + COLUMN_DURATION_FINGER_DB +" INTEGER"
                    +")";

    //getter methods

    public int getRollno() {
        return rollno;
    }
    public int getFingerid() {
        return fingerid;
    }

    public String getCandidateImage() {
        return candidateImage;
    }

    public String getFingerimage() {
        return fingerimage;
    }

    public String getFingerstring() {
        return fingerstring;
    }

    public String getStartDateTime() {
        return startDateTime;
    }

    public String getEndDateTime() {
        return endDateTime;
    }

    public int getStartFlag() {
        return startFlag;
    }

    public int getEndFlag() {
        return endFlag;
    }
    public int getDuration() {
        return duration;
    }
    //setter methods

    public void setCandidateImage(String candidateImage) {
        this.candidateImage = candidateImage;
    }

    public void setFingerid(int fingerid) {
        this.fingerid = fingerid;
    }

    public void setFingerimage(String fingerimage) {
        this.fingerimage = fingerimage;
    }

    public void setFingerstring(String fingerstring) {
        this.fingerstring = fingerstring;
    }

    public void setRollno(int rollno) {
        this.rollno = rollno;
    }


    public void setStartDateTime(String startDateTime) {
        this.startDateTime = startDateTime;
    }

    public void setEndDateTime(String endDateTime) {
        this.endDateTime = endDateTime;
    }


    public void setStartFlag(int startFlag) {
        this.startFlag = startFlag;
    }

    public void setEndFlag(int endFlag) {
        this.endFlag = endFlag;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }
}
